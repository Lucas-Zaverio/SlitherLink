# -*- coding: utf-8 -*-

from fltk import *
from random import *

from variable import *
from function import *

# BOUCLE DE JEU
while game: 
    
    # MENU DE JEU
    if __name__  == "__main__":
        jouer = False
        menu = open_menu()
        while menu:
            event, type = evenement()
            game, menu, jouer, info, parametre  = interaction_menu(type,event)
                    

    # MENU INFORMATION / PARAMETRE
    if info:
        information = open_info()
        while information:
            event, type = evenement()
            game, menu, jouer, information  = interaction_info(type,event)
            

    # L'AVANT PARTIE
    if parametre:
        param = open_param()
        while param:
            event, type = evenement()
            game,  menu , param, jouer, carte  = interaction_param(type,event,Facile,Moyen,Difficile)
                

    # LA PARTIE    
    if jouer:
        ferme_fenetre()
        seg_depart = 0
        grille = carte_creation(carte)
        etat = interface_graphique(len(grille[0]),len(grille),taille_case,taille_marge,grille)
        
        while True:
            
            event, type = evenement()
            
            if type == "ClicGauche":
                segment,trait_x,trait_y = recherche_segment(event,len(grille[0]),len(grille),taille_case, taille_marge)
                if trait_x == True or trait_y == True:
                    if seg_depart == 0:
                            seg_depart, depart, precedent, courant, seg_parcours= 1,segment[0],segment[0],segment[1],0 
                    _trait_,liste_sauvegarde = tracage(etat,segment, taille_case, taille_marge,sauvegarde, liste_sauvegarde)
                    win_1 = (statuts_verif(grille, etat))
                    longueur = longueur_boucle(etat, segment, depart, precedent, courant, seg_parcours, _trait_,liste_segments)
                    print(win_1,longueur)
                    precedent, courant, seg_parcours = longueur[1], longueur[2], longueur[3]
                    victoire(win_1,longueur[0],taille_case,taille_marge,len(grille[0]),len(grille))
                                                                           
            # Pour préciser qu'une ligne ne doit pas être tracé
            elif type == "ClicDroit":
                segment,trait_x,trait_y = recherche_segment(event,len(grilles[0]),len(grille),taille_case, taille_marge)
                if trait_x == True or trait_y == True:
                    croix(etat,segment, taille_case, taille_marge)
    
            elif type == "Touche":
                
                # CODE TRICHE PAS 100 % 
                if touche(event) == "e" or touche(event) == "E":
                    print("Code Triche")
                    print(bot_resolve(sommet, etat, grille))
                    
                # / FONCTIONNALITE BROUILLON /
                elif touche(event) == "s" or touche(event) == "S":
                    sauvegarde, liste_sauvegarde = mode_sauvegarde(sauvegarde, liste_sauvegarde, etat, taille_case, taille_marge)
    
    
            if type == 'Quitte':
                jouer, game = False, False                                
                break
    
    ferme_fenetre()