# -*- coding: utf-8 -*-

from fltk import *
from random import *


def evenement():
    event = donne_ev()
    type = type_ev(event)
    mise_a_jour()
    return event, type

                ### ### ### ___ --- MENUS --- ___ ### ### ###

def jeu_graphique(largeur,hauteur,taille_case,taille_marge):

    cree_fenetre(taille_case*largeur+taille_marge*2,taille_case*hauteur+taille_marge*2)
    rectangle(0,0,taille_case*largeur+taille_marge*largeur,taille_case*hauteur+taille_marge*hauteur,couleur='white', remplissage='white')

def open_menu():

    cree_fenetre(700,700)
    image(350, 350, "images/background.png", ancrage = "center") 
    return True
    
def open_param():
    
    image(350, 350, "images/back_param.png", ancrage = "center") 
    return True

def open_info():
    
    image(350, 350, "images/back_info.png", ancrage = "center") 
    return True

def clic_menu(event):
    
    # Bouton pour jouer
    if 211 <= abscisse(event) <= 478 and 432 <= ordonnee(event) <= 507:
        return True, False, True, False, True
        
    # Bouton paramètres    
    elif 653 <= abscisse(event) <= 692 and 5 <= ordonnee(event) <= 44:
        return True, False, False, True, False
    
    else:
        return True, True, False, False, False
    
def interaction_menu(type, event):
    
            if type == 'Quitte':
                
                return False, False, False, False, False
            
            elif type == 'ClicGauche':
        
                return clic_menu(event)
            
            else:
                return True, True, False, False, False
                
    
    
def clic_info(event):
    # Bouton Retour
    if 7 <= abscisse(event) <= 48 and 6 <= ordonnee(event) <= 50:
        return True, True, False, False
    else:
        return True, False, False, True
    
def interaction_info(type,event):
    
            if type == 'Quitte':
                
                return False, False, False, False
            
            elif type == 'ClicGauche':
                
                return clic_info(event)
            
            else:
                return True, False, False, True
            
def clic_param(event,Facile,Moyen,Difficile):
    
    # Bouton Retour
    if 7 <= abscisse(event) <= 48 and 6 <= ordonnee(event) <= 50:
        return True, True, False, False, None
        
    # TRIVIAL
    elif 63 <= abscisse(event) <= 330 and 285 <= ordonnee(event) <= 360:
        return True, False, False, True, "grilles/grille-triviale.txt"
        
    # FACILE
    elif 370 <= abscisse(event) <= 637 and 285 <= ordonnee(event) <= 360:
       print("1")
       return True, False, False, True, choice(Facile)
        
    # MOYEN
    elif 63 <= abscisse(event) <= 330 and 458 <= ordonnee(event) <= 533:
        return True, False, False, True, choice(Moyen)
    
    # DIFFICILE
    elif 370 <= abscisse(event) <= 637 and 458 <= ordonnee(event) <= 533:
        print("2")
        return True, False, False, True, choice(Difficile)
    
    else: 
        return True, False, True, False, None
    
    
def interaction_param(type,event,Facile,Moyen,Difficile):
    
    if type == 'Quitte':
        return True, False, False, False, None
    
    elif type == 'ClicGauche':
        
        return clic_param(event,Facile,Moyen,Difficile)
    
    else:
        return True, False, True, False, None
                
    
def recherche_segment(event,largeur,hauteur,taille_case, taille_marge):

    trait_x = fct_abc(abscisse(event),largeur,hauteur,taille_case, taille_marge)
    trait_y = fct_abc(ordonnee(event),largeur,hauteur,taille_case, taille_marge)

    return cherche_segment(abscisse(event),ordonnee(event), taille_case,taille_marge), trait_x,trait_y
                    



                ### ### ### ___ --- FONCTIONS IMPORTANTS --- ___ ### ### ###
def angle(largeur,hauteur,taille_case,taille_marge):

    for i in range(largeur+1):
        for j in range(hauteur+1):
            point(taille_marge + i * taille_case, taille_marge + j * taille_case,epaisseur = 2)
            

def indice(grille,taille_case):

    temp_1 = -taille_case
    for i in grille:
        temp_1 += taille_case
        temp_2 = -taille_case
        for cont in i:
            temp_2 += taille_case
            if cont != None:
                y,x = temp_1+taille_case/2, temp_2+taille_case/2
                texte(x,y,cont)

def clic_x(largeur,hauteur,taille_case,taille_marge, x):

    for i in range(largeur+1):
        for j in range(hauteur+1):
            if - 5 < x - (taille_marge + i * taille_case) < 5:
                return True
    return False

def clic_y(largeur,hauteur,taille_case,taille_marge, y):

    for i in range(largeur+1):
        for j in range(hauteur+1):
            if - 5 < y - (taille_marge + j * taille_case) < 5:
                return True
    return False

def fct_abc(x,a,b,taille_case, taille_marge):
    
    return clic_x(a,b,taille_case, taille_marge, x)

def fct_ord(y,a,b,taille_case, taille_marge):
    
    return clic_y(a,b,taille_case, taille_marge, y)
    

def carte_creation(carte):
    """Fonction renvoyant la liste grille grace à l'ouverture du fichier 
    au préalable"""
    fichier = open(carte, "r")
    carte = fichier.readlines()
    fichier.close()
    grille = grille_creation(carte)    
    return grille
    
def grille_creation(carte, grille = []):
    """ Fonction renvoyant une liste grille dans laquelle on retrouve
    les coordonnées des case d'un ficher"""
    
    for ligne in range(len(carte)):
        temp = []
        for case in range(len(carte[ligne])):
            if carte[ligne][case] == "_":
                temp.append(None)    
            elif carte[ligne][case] != "\n":
                temp.append(int(carte[ligne][case]))
        grille.append(temp)
    return grille


def interface_graphique(largeur,hauteur,taille_case,taille_marge,grille):
    
    jeu_graphique(len(grille[0]),len(grille),taille_case,taille_marge)
    angle(len(grille[0]),len(grille),taille_case,taille_marge)
    indice(grille, taille_case)
    return cotes_dico(grille)

                ### ### ### ___ --- INTERFACE GRAPHIQUE --- ___ ### ### ###
                
def tracage(etat, segment, taille_case, taille_marge,sauvegarde,liste_sauvegarde):
    
    if est_interdit(etat, segment) == False and not sauvegarde:
        if est_trace(etat, segment):
            effacer_segment(etat, segment)
            ligne(segment[0][0]*taille_case+taille_marge,
                  segment[0][1]*taille_case+taille_marge,
                  segment[1][0]*taille_case+taille_marge,
                  segment[1][1]*taille_case+taille_marge, 
                  couleur="white")
            return "blank",liste_sauvegarde
        else:
            tracer_segment(etat, segment)
            ligne(segment[0][0]*taille_case+taille_marge,
                  segment[0][1]*taille_case+taille_marge,
                  segment[1][0]*taille_case+taille_marge,
                  segment[1][1]*taille_case+taille_marge)
            return "plein",liste_sauvegarde
    elif est_interdit(etat, segment) == False and sauvegarde:
        if est_trace(etat, segment):
            effacer_segment(etat, segment)
            ligne(segment[0][0]*taille_case+taille_marge,
                  segment[0][1]*taille_case+taille_marge,
                  segment[1][0]*taille_case+taille_marge,
                  segment[1][1]*taille_case+taille_marge, 
                  couleur="white")
            liste_sauvegarde.remove(segment)
            return "blank",liste_sauvegarde
        else:
            tracer_segment(etat, segment)
            ligne(segment[0][0]*taille_case+taille_marge,
                  segment[0][1]*taille_case+taille_marge,
                  segment[1][0]*taille_case+taille_marge,
                  segment[1][1]*taille_case+taille_marge,
                  couleur="blue")
            liste_sauvegarde.append(segment)
            return "plein",liste_sauvegarde
    else:
        return "croix",liste_sauvegarde
    
    
def mode_sauvegarde(sauvegarde, liste_sauvegarde, etat, taille_case, taille_marge):
    if sauvegarde:
        print("Mode sauvegarde Inactif")
        sauvegarde = False
        for i in range(len(liste_sauvegarde)):
            effacer_segment(etat, liste_sauvegarde[i])
            ligne(liste_sauvegarde[i][0][0]*taille_case+taille_marge,
                  liste_sauvegarde[i][0][1]*taille_case+taille_marge,
                  liste_sauvegarde[i][1][0]*taille_case+taille_marge,
                  liste_sauvegarde[i][1][1]*taille_case+taille_marge, 
                  couleur="white")
    
    else:   
        print("Mode sauvegarde Actif")
        sauvegarde = True
        liste_sauvegarde = []
    return sauvegarde,liste_sauvegarde
     
def croix(etat, segment, taille_case, taille_marge):

    if not est_trace(etat,segment):
        if est_interdit(etat, segment):
            effacer_segment(etat, segment)
            if segment[0][0] == segment[1][0]:
                vertical_supcroix(segment,taille_case,taille_marge)
            else:   horizontal_supcroix(segment,taille_case,taille_marge)
        else:
            interdire_segment(etat, segment)
            if segment[0][0] == segment[1][0]:
                vertical_croix(segment,taille_case,taille_marge)
            else: horizontal_croix(segment,taille_case,taille_marge)

def vertical_croix(segment,taille_case,taille_marge):

    ligne(segment[0][0]*taille_case,
            segment[0][1]*taille_case+taille_case/2,
            segment[1][0]*taille_case+taille_marge*2,
            segment[1][1]*taille_case-taille_case/3,
            couleur="red", epaisseur="2")

    ligne(segment[0][0]*taille_case+taille_marge*2,
            segment[0][1]*taille_case+taille_case/2,
            segment[1][0]*taille_case,
            segment[1][1]*taille_case-taille_case/3,
            couleur="red", epaisseur="2")

def horizontal_croix(segment,taille_case,taille_marge):

    ligne(segment[0][0]*taille_case+taille_case/2,
            segment[0][1]*taille_case,
            segment[1][0]*taille_case-taille_case/3,
            segment[1][1]*taille_case+taille_marge*2,
            couleur="red", epaisseur="2")

    ligne(segment[0][0]*taille_case+taille_case/2,
            segment[0][1]*taille_case+taille_marge*2,
            segment[1][0]*taille_case-taille_case/3,
            segment[1][1]*taille_case,
            couleur="red", epaisseur="2")

def vertical_supcroix(segment,taille_case,taille_marge):

    ligne(segment[0][0]*taille_case,
            segment[0][1]*taille_case+taille_case/2,
            segment[1][0]*taille_case+taille_marge*2,
            segment[1][1]*taille_case-taille_case/3,
            couleur="white", epaisseur="2")

    ligne(segment[0][0]*taille_case+taille_marge*2,
            segment[0][1]*taille_case+taille_case/2,
            segment[1][0]*taille_case,
            segment[1][1]*taille_case-taille_case/3,
            couleur="white", epaisseur="2")

def horizontal_supcroix(segment,taille_case,taille_marge):

    ligne(segment[0][0]*taille_case+taille_case/2,
            segment[0][1]*taille_case,
            segment[1][0]*taille_case-taille_case/3,
            segment[1][1]*taille_case+taille_marge*2,
            couleur="white", epaisseur="2")

    ligne(segment[0][0]*taille_case+taille_case/2,
            segment[0][1]*taille_case+taille_marge*2,
            segment[1][0]*taille_case-taille_case/3,
            segment[1][1]*taille_case,
            couleur="white", epaisseur="2")
    

def cotes_dico(indices):
    """Fonction renvoyant un dictionnaire avec l'entièreté des relations entre cotés."""

    etat = {}
    for i in range(len(indices)+1):
        for j in range(len(indices[0])):
            etat[(i,j),(i,j+1)] = 0
    for h in range(len(indices)+1):
        for k in range(len(indices[0])+1):
            etat[(h,k),(h+1,k)] = 0
    return etat

                ### ### ### ___ --- FONCTIONS SEGMENTS --- ___ ### ### ###

def est_trace(etat, segment):
    """ Fonction renvoyant True si segment est tracé dans etat, et False sinon """
    if (segment in etat):
        if etat[segment] == 1:
            return True
        else: return False

def est_interdit(etat, segment) : 
    """ Fonction renvoyant True si segment est interdit dans etat, et False sinon """
    if (segment in etat):
        if etat[segment] == -1:
            return True
        else: return False
    
def est_vierge(etat, segment) : 
    """ Fonction renvoyant True si segment est vierge dans etat, et False sinon """
    if (segment not in etat):
        return True
    
def tracer_segment(etat, segment):
    """Fonction modifiant etat afin de représenter le fait que segment est maintenant tracé """
    etat[segment] = 1
    return etat

def cherche_segment(x,y,taille_case,taille_marge):

    bord = [taille_marge,
            taille_case+taille_marge,
            taille_case*2+taille_marge,
            taille_case*3+taille_marge,
            taille_case*4+taille_marge,
            taille_case*5+taille_marge,
            taille_case*6+taille_marge,
            taille_case*7+taille_marge,
            taille_case*8+taille_marge]

    for i in bord:
        if i-5 < x < i+5:
            return ((x//120,y//120),((x//120),(y//120)+1))
    return ((x//120,y//120),((x//120)+1,y//120))
    
    

def interdire_segment(etat, segment):
    """ Fonction  modifiant etat afin de représenter le fait que segment est maintenant interdit """
    etat[segment] = -1
    return etat



def effacer_segment(etat, segment): 
    """ Fonction modifiant etat afin de représenter le fait que segment est maintenant vierge. 
        Attention, effacer un segment revient à retirer de l’information du dictionnaire etat """
    etat[segment] = 0
    return etat


def segments_traces(etat, sommet) : 
    """ Fonction renvoyant la liste des segments tracés adjacents à sommet dans etat """  
    liste_trace=[]
    if ((sommet[0]-1,sommet[1]) in etat):
        if (etat[sommet[0]-1,sommet[1]]) == 1:
            liste_trace.append((sommet[0]-1,sommet[1]))
    if ((sommet[0]+1,sommet[1]) in etat):
        if (etat[sommet[0]+1,sommet[1]]) == 1:
            liste_trace.append((sommet[0]+1,sommet[1]))
    if ((sommet[0],sommet[1]-1) in etat):
        if (etat[sommet[0],sommet[1]-1]) == 1:
            liste_trace.append((sommet[0],sommet[1]-1))
    if ((sommet[0],sommet[1]+1) in etat):
        if (etat[sommet[0],sommet[1]+1]) == 1:
            liste_trace.append((sommet[0]-1,sommet[1]+1))
    return liste_trace


def segments_interdits(etat, sommet) : 
    """ Fonction renvoyant la liste des segments interdits adjacents sommet dans etat """
    liste_interdit=[]
    if ((sommet[0]-1,sommet[1]) in etat):
        if (etat[sommet[0]-1,sommet[1]]) == -1:
            liste_interdit.append((sommet[0]-1,sommet[1]))
    if ((sommet[0]+1,sommet[1]) in etat):
        if (etat[sommet[0]+1,sommet[1]]) == -1:
            liste_interdit.append((sommet[0]+1,sommet[1]))
    if ((sommet[0],sommet[1]-1) in etat):
        if (etat[sommet[0],sommet[1]-1]) == -1:
            liste_interdit.append((sommet[0],sommet[1]-1))
    if ((sommet[0],sommet[1]+1) in etat):
        if (etat[sommet[0],sommet[1]+1]) == -1:
            liste_interdit.append((sommet[0]-1,sommet[1]+1))
    return liste_interdit


def segments_vierges(etat, sommet,liste_vierge=[]): 
    """Fonction renvoyant la liste des segments vierges adjacents à sommet dans etat """
    if ((sommet[0]-1,sommet[1]) not in etat):
        liste_vierge.append((sommet[0]-1,sommet[1]))
    if ((sommet[0]+1,sommet[1]) not in etat):
        liste_vierge.append((sommet[0]+1,sommet[1]))
    if ((sommet[0],sommet[1]-1) not in etat):
        liste_vierge.append((sommet[0],sommet[1]-1))
    if ((sommet[0],sommet[1]+1) not in etat):
        liste_vierge.append((sommet[0]-1,sommet[1]+1))
    return liste_vierge

        



                ### ### ### ___ --- FONCTIONS VICTOIRE --- ___ ### ### ###
                
def verification(verif_indices):

    for i in range(len(verif_indices)//2):
        if verif_indices[i] == -1 or verif_indices[i] == 1:
            return False
    return True

def statuts_verif(indices, etat):
    verif_list=[]
    for i in range(len(indices)):
        for j in range(len(indices[i])):
            a = (statut_case(indices, etat, [i,j]))
            verif_list.append(a)
    print(verif_list)
    return verification(verif_list)

def statut_case(indices, etat, case):
    """ Fonction recevant le tableau d’indices, l’état de la grille et les
        coordonnées d’une case (pas d’un sommet !) et renvoyant None si cette case ne porte aucun indice, et un nombre entier sinon :
            – 0 si l’indice est satisfait ;
            – positif s’il est encore possible de satisfaire l’indice en traçant des segments autour de la case ;
            – négatif s’il n’est plus possible de satisfaire l’indice parce que trop de segments sont déjà tracés ou interdits autour de la case."""
    trace,interdit = 0,0
    if indices[case[0]][case[1]] == None:
        return None
    if ((case[1],case[0]),(case[1]+1,case[0]) in etat):
        if est_trace(etat, ((case[1],case[0]),(case[1],case[0]+1))):
            trace += 1
        else: interdit += 1
        if est_trace(etat, ((case[1],case[0]),(case[1]+1,case[0]))):
            trace += 1
        else: interdit += 1
        if est_trace(etat, ((case[1]+1,case[0]),(case[1]+1,case[0]+1))):
            trace += 1
        else: interdit += 1
        if est_trace(etat, ((case[1],case[0]+1),(case[1]+1,case[0]+1))):
            trace += 1
        else: interdit += 1
        if trace == indices[case[0]][case[1]]:
            return 0
        elif trace < indices[case[0]][case[1]] or trace + interdit < indices[case[0]][case[1]]:
            return 1
        elif trace > indices[case[0]][case[1]] or interdit - trace >= indices[case[0]][case[1]]:
            return -1
                
def longueur_boucle(etat, segment, depart, precedent, courant,seg_parcours,_trait_,liste_segments):

    seg_parcours += 1
    if _trait_ == "blank":
        if liste_segments:
            courant = liste_segments[-1]
            liste_segments.pop()
    indice = verif_seg_depart(etat,depart)

    if courant != depart:
        indice_2 = verif_seg_courant(etat,courant)
        if indice_2 != 2:
            print("1")
            return [False,precedent,courant,seg_parcours]
        else:
            liste_segments.append(precedent)
            precedent = courant
            courant_temp = seg_courant_adja(etat,courant,precedent)
            courant = courant_temp[1]
        if indice != 2: 
            print("2")
            return [False,precedent,courant,seg_parcours,liste_segments]
    return [True,precedent,courant,seg_parcours,liste_segments]
    
    if indice != 2: 
        print("3")
        return [False,precedent,courant,seg_parcours]

def seg_courant_adja(etat,courant,precedent):
    
    if ((courant,(courant[0]+1,courant[1])) in etat):
        if (etat[(courant,(courant[0]+1,courant[1]))] == 1  
            and (courant,(courant[0]+1,courant[1])) != precedent):
            return (courant,(courant[0]+1,courant[1]))
    
    if (((courant[0]+1,courant[1]),courant) in etat):
        if (etat[((courant[0]+1,courant[1]),courant)] == 1
            and ((courant[0]+1,courant[1]),courant) != precedent):
            return ((courant[0]+1,courant[1]),courant)
            
            
    if ((courant,(courant[0],courant[1]+1)) in etat):
        if (etat[(courant,(courant[0],courant[1]+1))] == 1 
            and (courant,(courant[0],courant[1]+1)) != precedent):
            return (courant,(courant[0],courant[1]+1))
    
    if (((courant[0],courant[1]+1),courant) in etat):
        if (etat[((courant[0],courant[1]+1),courant)] == 1
            and ((courant[0],courant[1]+1),courant) != precedent):
            return ((courant[0],courant[1]+1),courant)
            
            
    if ((courant,(courant[0]-1,courant[1])) in etat):
        if (etat[(courant,(courant[0]-1,courant[1]))] == 1  
            and (courant,(courant[0]-1,courant[1])) != precedent):
            return (courant,(courant[0]-1,courant[1]))
    
    if (((courant[0]-1,courant[1]),courant) in etat):
        if (etat[((courant[0]-1,courant[1]),courant)] == 1
            and ((courant[0]-1,courant[1]),courant) != precedent):
            return ((courant[0]-1,courant[1]),courant)
            
            
    if ((courant,(courant[0],courant[1]-1)) in etat):
        if (etat[(courant,(courant[0],courant[1]-1))] == 1  
            and (courant,(courant[0],courant[1]-1)) != precedent):
            return (courant,(courant[0],courant[1]-1))
    
    if (((courant[0],courant[1]-1),courant) in etat):
        if (etat[(courant,(courant[0],courant[1]-1),courant)] == 1
            and ((courant[0],courant[1]-1),courant) != precedent):
            return ((courant[0],courant[1]-1),courant)

def verif_seg_courant(etat,courant,indice=0):
             
    if ((courant,(courant[0]+1,courant[1])) in etat):
        if etat[(courant,(courant[0]+1,courant[1]))] == 1:  
            indice += 1
    
    if (((courant[0]+1,courant[1]),courant) in etat):
        if etat[((courant[0]+1,courant[1]),courant)] == 1:
            indice += 1
            
            
    if ((courant,(courant[0],courant[1]+1)) in etat):
        if etat[(courant,(courant[0],courant[1]+1))] == 1:  
            indice += 1
    
    if (((courant[0],courant[1]+1),courant) in etat):
        if etat[((courant[0],courant[1]+1),courant)] == 1:
            indice += 1
            
            
    if ((courant,(courant[0]-1,courant[1])) in etat):
        if etat[(courant,(courant[0]-1,courant[1]))] == 1:  
            indice += 1
    
    if (((courant[0]-1,courant[1]),courant) in etat):
        if etat[((courant[0]-1,courant[1]),courant)] == 1:
            indice += 1
            
            
    if ((courant,(courant[0],courant[1]-1)) in etat):
        if etat[(courant,(courant[0],courant[1]-1))] == 1:  
            indice += 1
    
    if (((courant[0],courant[1]-1),courant) in etat):
        if etat[((courant[0],courant[1]-1),courant)] == 1:
            indice += 1
            
    return indice

def verif_seg_depart(etat,depart,indice=0):

    if ((depart,(depart[0]+1,depart[1])) in etat):
        if etat[(depart,(depart[0]+1,depart[1]))] == 1:
            indice += 1
    if ((depart,(depart[0],depart[1]+1)) in etat):
        if etat[(depart,(depart[0],depart[1]+1))] == 1:
            indice += 1 
    if ((depart,(depart[0]-1,depart[1])) in etat):
        if etat[(depart,(depart[0]-1,depart[1]))] == 1:
            indice += 1
    if ((depart,(depart[0],depart[1]-1)) in etat):
        if etat[(depart,(depart[0],depart[1]-1))] == 1:
            indice += 1
    if (((depart[0]+1,depart[1]),depart) in etat):
        if etat[((depart[0]+1,depart[1]),depart)] == 1:
            indice += 1
    if (((depart[0],depart[1]+1),depart) in etat):
        if etat[((depart[0],depart[1]+1),depart)] == 1:
            indice += 1 
    if (((depart[0]-1,depart[1]),depart) in etat):
        if etat[((depart[0]-1,depart[1]),depart)] == 1:
            indice += 1
    if (((depart[0],depart[1]-1),depart) in etat):
        if etat[((depart[0],depart[1]-1),depart)] == 1:
            indice += 1
    return indice
                
                
def victoire(param1,param2,taille_case,taille_marge,largeur,hauteur):
    print(param1,param2)
    if param1 == True and param2 == True:
        texte(10,taille_case*(hauteur/4)+taille_marge,"Vous avez gagné !",couleur="red")
        print("Vous avez gagné !")

                ### ### ### ___ --- FONCTIONS IA --- ___ ### ### ###
                
def bot_resolve(sommet, etat, indices):
    
    
     if bot_seg_adja(sommet,etat) == 2:
         """La boucle est bouclée."""
         print("test")
         if statuts_verif(grille, etat):
             print("FINNNNDDDDD !!!")
             return True
     elif bot_seg_adja(sommet,etat) > 2:
        return False
     elif bot_seg_adja(sommet,etat) < 2:
         temp_liste = [[1,0],[-1,0],[0,1],[0,-1]]
         for i in range(len(temp_liste)):
             seg_rajoute = (sommet[0]+temp_liste[i][0],sommet[1]+temp_liste[i][1])
             segment_bot = ((sommet),(seg_rajoute))
             if segment_bot not in etat:
                 segment_bot = ((seg_rajoute),(sommet))
             if segment_bot in etat:
                 etat = tracer_segment(etat, segment_bot)
                 validation = bot_statuts_verif(indices, etat)
                 if -1 in validation:
                     etat = effacer_segment(etat, segment_bot)
                 etat_solveur = bot_resolve(seg_rajoute, etat, indices)
                 if etat_solveur:
                     return True
                 elif etat_solveur == False:
                     etat = effacer_segment(etat, segment_bot)
         return False
             
         
    
def bot_statuts_verif(indices, etat):
    bot_verif_list=[]
    for i in range(len(indices)):
        for j in range(len(indices[i])):
            a = (statut_case(indices, etat, [i,j]))
            bot_verif_list.append(a)
    return bot_verif_list
    
    
def bot_seg_adja(sommet, etat, indice = 0):
    """
    compte le nb de seg adj, pour le solveur.
    """
     
    if ((sommet[0]+1,sommet[1]) in etat):
        if etat[(sommet[0]+1,sommet[1])] == 1:
            indice += 1
            
    if ((sommet[0],sommet[1]+1) in etat):
        if etat[(sommet[0],sommet[1]+1)] == 1:
            indice += 1
            
    if ((sommet[0]-1,sommet[1]) in etat):
        if etat[(sommet[0]-1,sommet[1])] == 1:
            indice += 1
            
    if ((sommet[0],sommet[1]-1) in etat):
        if etat[(sommet[0],sommet[1]-1)] == 1:
            indice += 1
            
    return indice
